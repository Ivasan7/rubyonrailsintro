class TodoOtem < ActiveRecord::Base
end
