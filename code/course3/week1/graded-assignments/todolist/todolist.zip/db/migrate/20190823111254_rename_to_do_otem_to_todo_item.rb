class RenameToDoOtemToTodoItem < ActiveRecord::Migration
  def change
  end
end
