class UserToTodolist < ActiveRecord::Migration
  def change
  end
end
