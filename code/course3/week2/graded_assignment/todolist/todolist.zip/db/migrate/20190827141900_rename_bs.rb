class RenameBs < ActiveRecord::Migration
  def change
  end
end
